import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import porterAlg.StaticStemer;
import porterAlg.Stemer1a;
import porterAlg.Stemer1b;
import porterAlg.Stemer1c;

public class IRMain {

    public static void main(String[] args) {
        StaticStemer.init();
        List<President> presidents = new ArrayList<President>();
        File f = new File(".\\Presidents");
        File[] files = f.listFiles();
        try {
            int totalWordCount = 0;
            for (File file : files) {
                Document doc = Jsoup.parse(file, "UTF-8");
                if (file.getName().equals("Bartlet.txt")) {
                    doc = Jsoup.parse(file, "UNICODE");
                }

                Elements elements = doc.select("p");
                President president = new President();
                String title = doc.title();
                if (title.length() > 35) {
                    String presName = title.substring(0, title.length() - 35);
                    president.setName(presName);
                    president.addReleventText(presName,
                            TuningParameters.titleTagWeight);
                }
                String text = "";
                for (Element element : elements) {
                    text = element.text();
                    president.addReleventText(text,
                            TuningParameters.bodyTextWeight);
                }

                // Use select for link words
                elements = doc.select("h2");
                for (Element element : elements) {
                    text = element.text();
                    president.addReleventText(text,
                            TuningParameters.anchorTagWeight);
                }
                
             // Use select for link words
                elements = doc.select("h3");
                for (Element element : elements) {
                    text = element.text();
                    president.addReleventText(text,
                            TuningParameters.anchorTagWeight);
                }
                presidents.add(president);
                totalWordCount += president.getWordCount();
            }
            double avgLength = ((double) totalWordCount)
                    / ((double) presidents.size());
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    System.in));
            System.out.println("Note, queries are not case sensitive");
            BM25 scoreAlg = new BM25(presidents, avgLength);
            while (true) {
                System.out
                        .println("Please type in a query or 'Quit' to quit: ");
                String input = br.readLine().toLowerCase();
                if (input.equals("quit")) {
                    break;
                }
                UnparsedQuery query = new UnparsedQuery(input);
                List<BM25.Listing> listings = scoreAlg.score(query);
                for (BM25.Listing listing : listings) {
                    if (listing.getScore() > 0) {
                        System.out.println(listing.toString());
                    }
                }
                System.out.println("\n\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // public static void main(String[] args) {
    // StaticStemer.init();
    // BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    // while (true) {
    // System.out.println("Please type in a query or 'Quit' to quit: ");
    // String input;
    // try {
    // input = br.readLine().toLowerCase();
    //
    // if (input.equals("quit")) {
    // break;
    // }
    // Query query = new Query(input);
    // for (String word : query.wordList) {
    // System.out.println(word);
    // }
    // } catch (IOException e) {
    // // TODO Auto-generated catch block
    // e.printStackTrace();
    // }
    // }
    // }
}

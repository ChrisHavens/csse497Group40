
public abstract class Query {
	String[] wordList;
	public abstract void handle(String words);
	
	public String[] getWordList(){
		return this.wordList;
	}
}

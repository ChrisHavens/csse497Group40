package defaultPackage;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
public class BM25 {
	List<President> presidents;
	double avgdl;
	final double k1=1.2;
	final double b=.75;
	public BM25(List<President> presidents, double avgdl){
		this.presidents=presidents;
		this.avgdl=avgdl;
	}
	public List<Listing> score(UnparsedQuery query){
		List<Listing> list=new ArrayList<Listing>();
		for (President p: presidents){
			Listing listing=new Listing(p.getName());
			listing.setScore(score(query, p));
			list.add(listing);
			
		}
		list.sort(new Comparator<Listing>(){

			@Override
			public int compare(Listing arg0, Listing arg1) {
				return -1*Double.compare(arg0.getScore(), arg1.getScore());	
			}
			
		});
		return list;
	}
	private double score(UnparsedQuery query, President p){
		double sum=0;
		String prevWord = "";
		for (String word: query.getWordList()){
			double idf=IDF(word);
			double fqid=p.getCountOfWord(word) + p.getBigramHitCount(prevWord, word);
			double num=fqid*(k1+1);
			double denom=fqid+(k1*(1-b+(b*(p.getWordCount()/avgdl))));
			double quo=num/denom;
			double term=idf*quo;
			sum+=term;
		}
		return sum;
		
	}
	private double IDF(String keyword){
		int nqi=numDocuments(keyword);
		
		double num=presidents.size()-nqi+0.5;
		double denom=nqi+0.5;
		double result=num/denom;
		return Math.abs(result);
		
	}
	private int numDocuments(String keyword){
		int num=0;
		for (President p: presidents){
			if (p.getCountOfWord(keyword)!=0){
				num++;
			}
		}
		return num;
	}
	public static class Listing{
		private String name;
		private double score;
		public Listing(String name){
			this.name=name;
		}
		public void setScore(double d){
			this.score=d;
		}
		public double getScore(){
			return this.score;
		}
		public String getName(){
			return this.name;
		}
		public String toString(){
			return name+", "+score;
		}
	}
}

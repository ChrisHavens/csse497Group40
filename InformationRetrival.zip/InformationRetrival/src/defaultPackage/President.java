package defaultPackage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import porterAlg.StaticStemer;

public class President {
    private String name;
    private HashMap<String, Integer> words;
    private int wordCount;
    private List<String> text;

    public President() {
        words = new HashMap<String, Integer>();
        wordCount = 0;
        text = new ArrayList<String>();
    }

    /*
     * 
     * This class assumes that the information desired as a result of queries is
     * just the name of the president.
     */

    public void addReleventText(String line, int weight) {
        String regex = "\\W";
        String[] wordList;
        wordList = line.split(regex);
        for (String word : wordList) {
            if (word.length() == 0) {
                continue;
            }

            word = word.toLowerCase();
            if (StaticStemer.useSteming){
                word = StaticStemer.stemWord(word);
            }
            text.add(word);
            wordCount++;
            int value;
            if (words.containsKey(word)) {
                value = words.get(word);
                value += weight;
            } else {
                value = 1;
            }
            words.put(word, value);
        }
    }

    public void printStats() {

        System.out.println(wordCount);

        Set<String> keys = words.keySet();

        String[] keysList = new String[1];

        keysList = keys.toArray(keysList);

        Arrays.sort(keysList);

        for (String key : keysList) {

            System.out.println(key + ": " + words.get(key));

        }

    }

    public String getName() {

        return name;

    }

    public void setName(String name) {

        this.name = name;

    }

    public int getWordCount() {

        return this.wordCount;

    }

    public int getCountOfWord(String word) {
        if (!this.words.containsKey(word)) {
            return 0;
        }

        return this.words.get(word);

    }

    public int getBigramHitCount(String firstWord, String secondWord) {
        if (firstWord.length() == 0 || secondWord.length() == 0) {
            return 0;
        }
        int count = 0;
        String farPrev = this.text.get(0);
        String prev = this.text.get(1);
        String current = this.text.get(2);
        for (int i = 2; i < this.wordCount; i++) {
            current = this.text.get(i);
            if (farPrev.equals(firstWord)
                    && (prev.equals(secondWord) || current.equals(secondWord))) {
                count ++;
            }
            farPrev = prev;
            prev = current;
        }

        return count;
    }

}
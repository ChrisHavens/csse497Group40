package defaultPackage;

public class TuningParameters {
    public static int titleTagWeight = 4;
    public static int anchorTagWeight = 2;
    public static int bodyTextWeight = 1;

}

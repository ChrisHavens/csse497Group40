package defaultPackage;
import porterAlg.StaticStemer;

public class UnparsedQuery extends Query{
	
	public UnparsedQuery(String query){
		 handle(query);
	}
	public void handle(String query){
		String regex = "\\W";
	     wordList = query.split(regex);      
	     if (StaticStemer.useSteming) {
	         for(int i = 0; i < wordList.length; i++) {
	             wordList[i] = StaticStemer.stemWord(wordList[i]);
	         }
	     }
	}
	
}

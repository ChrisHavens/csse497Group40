package parseTrees;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import defaultPackage.ParsedQuery;

public class ParseTree {
	String fileName;
	Set<String> wordList=new HashSet<String>();
	public ParseTree(String fileName,File file){
		this.fileName=fileName;
		try{
		Document doc = Jsoup.parse(file, "UTF-8");
        
        Elements elements = doc.select("lemma");
        
        for (Element element : elements) {
            String text = element.text();
            wordList.add(text);
        }
		}catch(Exception e){
			
		}
	}
	public boolean match(ParsedQuery q){
		int contWords=0;
		int totalWords=q.getWordList().length;
		for (String word: q.getWordList()){
			if (wordList.contains(word)){
				contWords++;
			}
		}
		//System.out.println("here");
		if ((contWords*1.0)/totalWords >=.75){
			return true;
		}
		else if (contWords==1 && totalWords<=3){
			return true;
		}
		return false;
	}

}

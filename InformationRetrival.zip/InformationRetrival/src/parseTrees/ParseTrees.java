package parseTrees;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import defaultPackage.BM25;
import defaultPackage.ParsedQuery;
import edu.stanford.nlp.dcoref.CorefCoreAnnotations.CorefChainAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.*;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.CoreNLPProtos.CorefChain;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.semgraph.SemanticGraph;
import edu.stanford.nlp.semgraph.SemanticGraphCoreAnnotations.CollapsedCCProcessedDependenciesAnnotation;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeCoreAnnotations.TreeAnnotation;
import edu.stanford.nlp.util.CoreMap;

public class ParseTrees {
	public static void main(String[] args){
		BufferedReader br = new BufferedReader(new InputStreamReader(
                System.in));
        System.out.println("Note, queries are not case sensitive");
        String query="president";
        while (true) {
            System.out
                    .println("Please type in a query or 'Quit' to quit: ");
            
			try {
				String input;
				input = br.readLine().toLowerCase();
				if (input.equals("quit")) {
	                break;
	            }
	            else{
	            	query=input;
	            	break;
	            }
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            
            System.out.println("\n\n");
        }
        List<String> fileNames=new ArrayList<String>();
        ParsedQuery pq=new ParsedQuery(query);
		 File f = new File(".\\xmls");
	        File[] files = f.listFiles();
	        try {
	            for (File file : files) {
	            	String fileName;
	                String fName= file.getName().substring(0, file.getName().length()-4);
	                System.out.println(fName);
	                if (fName.equals("Benjamin_Harrison.txt")){
	                	fileName="BenjaminHarrison.txt";
	                }
	                else if (fName.equals("Franklin_D._Roosevelt.txt")){
	                	fileName="FDR.txt";
	                }
	                else if (fName.equals("George_W._Bush.txt")){
	                	fileName="GWBush.txt";
	                }
	                else if (fName.equals("John_Quincy_Adams.txt")){
	                	fileName="JohnQuincyAdams.txt";
	                }
	                else if (fName.equals("Lyndon_B._Johnson.txt")){
	                	fileName="LBJ.txt";
	                }
	                else if (fName.equals("Theodore_Roosevelt.txt")){
	                	fileName="TeddyRoosevelt.txt";
	                }
	                else if (fName.equals("Martin_Van_Buren.txt")){
	                	fileName="vanBuren.txt";
	                }
	                else{
	                	String[] splits=fName.split("_");
	                	fileName=splits[splits.length-1];
	                }
	                ParseTree p=new ParseTree(fileName, file);
	                if (p.match(pq)){
	                	System.out.println("match");
	                	fileNames.add(fileName);
	                }
	             // Use select for link words
	                
	            }
	        }catch(Exception e){
	        	e.printStackTrace();
	        }
	        System.out.println(fileNames);
	}

}

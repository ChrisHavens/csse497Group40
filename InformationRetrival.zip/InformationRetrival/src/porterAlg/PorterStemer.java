package porterAlg;

public abstract interface PorterStemer {
    
    public boolean requiresSteming(String word);
    public String stemWord(String word);
    public default String stripLetters(String word, int removeAmount) {
        return word.substring(0, word.length() - removeAmount);
    }

}

package porterAlg;
import java.util.ArrayList;
import java.util.List;

public class PorterWord {
    private String originalWord;
    private List<String> pieces;
    private int measure = 0;
    private boolean startsWithVowel;
    private boolean hasVowel = false;

    public PorterWord(String word) {
        originalWord = word;
        pieces = new ArrayList<String>();
        char[] letters = word.toCharArray();
        String currentPiece = null;
        boolean prevWasVowel = false;
        for (int i = 0; i < letters.length; i++) {
            char letter = letters[i];
            boolean vowel = (letter == 'a' || letter == 'e' || letter == 'i'
                    || letter == 'o' || letter == 'u');
            // Deal with case for y
            if (letter == 'y') {
                vowel = !prevWasVowel;
            }
            hasVowel = hasVowel || vowel;
            if (currentPiece == null){
                startsWithVowel = vowel;
            }

            if (vowel != prevWasVowel) {
                if (currentPiece != null) {
                    pieces.add(currentPiece);
                }
                currentPiece = Character.toString(letter);
                if (prevWasVowel) {
                    measure++;
                }
            }
            currentPiece += letter;
            prevWasVowel = vowel;
        }
        pieces.add(currentPiece);
    }

    public String getWord() {
        return originalWord;
    }

    public List<String> getPieces() {
        return pieces;
    }
    
    public int getMeasure() {
        return this.measure;
    }
    
    public boolean getVowelStart(){
        return this.startsWithVowel;
    }
    
    public boolean hasVowel(){
        return this.hasVowel;
    }
}

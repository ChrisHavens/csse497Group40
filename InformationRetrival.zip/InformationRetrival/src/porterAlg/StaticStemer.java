package porterAlg;
import java.util.ArrayList;
import java.util.List;


public class StaticStemer {


    public static List<PorterStemer> stemers = new ArrayList<PorterStemer>();
    public static boolean useSteming = true;
    
    public static String stemWord(String word){
        for(PorterStemer stemer: stemers){
            if (stemer.requiresSteming(word)){
                return stemer.stemWord(word);
            }
        }
        return word;
    }
    
    public static String stemWord(String word, PorterStemer stemer){
        String modifiedString = word;
        if (stemer.requiresSteming(word)){
            modifiedString = stemer.stemWord(word);
        }
        return modifiedString;
    }
    
    public static void init() {
        stemers.add(new Stemer1a());
        stemers.add(new Stemer1b());
        stemers.add(new Stemer1c());
    }
    
    
}

package porterAlg;
public class Stemer1a implements PorterStemer {

    @Override
    public boolean requiresSteming(String word) {
        if (word.endsWith("sses")) {
            return true;
        }
        if (word.endsWith("ies")) {
            return true;
        }
        if (word.endsWith("ss")) {
            return true;
        }
        if (word.endsWith("s")) {
            return true;
        }
        return false;
    }

    @Override
    public String stemWord(String word) {
        int len = word.length();
        int removeAmount = 0;
        String replacement = "";
        if (word.endsWith("sses")) {
            removeAmount = 4;
            replacement = "ss";
        } else if (word.endsWith("ies")) {
            removeAmount = 3;
            replacement = "i";
        } else if (word.endsWith("ss")) {
            removeAmount = 2;
            replacement = "ss";
        } else if (word.endsWith("s")) {
            removeAmount = 1;
            replacement = "";
        }
        return this.stripLetters(word, removeAmount) + replacement;
    }

}

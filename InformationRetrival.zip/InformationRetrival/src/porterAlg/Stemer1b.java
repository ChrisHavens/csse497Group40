package porterAlg;

public class Stemer1b implements PorterStemer {

    @Override
    public boolean requiresSteming(String word) {
        if (word.endsWith("eed")) {
            String stem = this.stripLetters(word, 3);
            PorterWord pWord = new PorterWord(stem);
            if (pWord.getMeasure() > 0) {
                return true;
            }
        }
        if (word.endsWith("ed")) {
            String stem = this.stripLetters(word, 2);
            PorterWord pWord = new PorterWord(stem);
            if (pWord.hasVowel()) {
                return true;
            }
        }
        if (word.endsWith("ing")) {
            String stem = this.stripLetters(word, 3);
            PorterWord pWord = new PorterWord(stem);
            if (pWord.hasVowel()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String stemWord(String word) {
        int removeAmount = 0;
        String replacement = "";
        if (word.endsWith("eed")) {
            String stem = this.stripLetters(word, 3);
            PorterWord pWord = new PorterWord(stem);
            if (pWord.getMeasure() > 0) {
                removeAmount = 3;
                replacement = "ee";
            }
        } else if (word.endsWith("ed")) {
            String stem = this.stripLetters(word, 2);
            PorterWord pWord = new PorterWord(stem);
            if (pWord.hasVowel()) {
                return SubStemer1b.stemWord(stem);
            }
        } else if (word.endsWith("ing")) {
            String stem = this.stripLetters(word, 3);
            PorterWord pWord = new PorterWord(stem);
            if (pWord.hasVowel()) {
                return SubStemer1b.stemWord(stem);
            }
        }
        return this.stripLetters(word, removeAmount) + replacement;
    }

}

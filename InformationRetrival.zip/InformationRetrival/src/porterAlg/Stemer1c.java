package porterAlg;

public class Stemer1c implements PorterStemer {

    @Override
    public boolean requiresSteming(String word) {
        return word.endsWith("y");
    }

    @Override
    public String stemWord(String word) {

        int removeAmount = 0;
        String replacement = "";
        if (word.endsWith("y")) {
            String stem = this.stripLetters(word, 1);
            PorterWord pWord = new PorterWord(stem);
            if (pWord.hasVowel()) {
                removeAmount = 1;
                replacement = "i";
            }
        }
        return this.stripLetters(word, removeAmount) + replacement;
    }

}

package porterAlg;

/**
 * This takes care of the first half of the second step for step 1b, but the
 * second half is ignored for now as it is overly complex
 *
 */
public class SubStemer1b {

    public static boolean requiresSteming(String word) {
        return false;
    }

    public static String stemWord(String word) {
        String replace = "";
        if (word.endsWith("at")) {
            replace = "e";
        } else if (word.endsWith("bl")) {
            replace = "e";
        } else if (word.endsWith("iz")) {
            replace = "e";
        }
        return word + replace;
    }

}
